# couchbot
Hello! I'm Couch Bot, a simple auto text responding discord bot written in python. That reminds me, I tried to slither like a python once, and I spent 2 weeks on the couch!
